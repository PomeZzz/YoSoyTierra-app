<div align="center">

  <img src="https://i.postimg.cc/bNzC5Nkq/254065526-317972119711089-8205851312934076105-n.jpg" alt="Project Banner">
    



  <div>
    <img src="https://img.shields.io/badge/-React_Native-black?style=for-the-badge&logoColor=white&logo=react&color=61DAFB" alt="react-native" />
    <img src="https://img.shields.io/badge/-React_Native_Reanimated-black?style=for-the-badge&logoColor=white&logo=react&color=61DAFB" alt="react-native-reanimated" />
    <img src="https://img.shields.io/badge/-Node.js-black?style=for-the-badge&logoColor=white&logo=node.js&color=339933" alt="node.js" />
    <img src="https://img.shields.io/badge/-Expo-black?style=for-the-badge&logoColor=white&logo=expo&color=000020" alt="expo" />
    <img src="https://img.shields.io/badge/Figma-F24E1E?style=for-the-badge&logo=figma&logoColor=white" alt="figma" />
    <img src="https://img.shields.io/badge/Laravel-FF2D20?style=for-the-badge&logo=laravel&logoColor=white" alt="Laravel" />          
  </div>

  <h3 align="center">Full Stack SujiNavi App</h3>
</div>

## 📋 Table of Contents

1. 🤖 [Introduction](#introduction)
2. ⚙️ [Tech Stack](#tech-stack)
3. 🔗 [Links](#links)

## <a name="introduction">🤖 Introduction</a>
YoSoyTierra-App.
Aplicacion mobil de compra venta de cosmetica natural.

## <a name="tech-stack">⚙️ Tech Stack</a>
- **React Native**
- **React Native Reanimated**
- **Node.js**
- **Expo**
- **Laravel**
- **Figma**

## <a name="links">🔗 Links</a>
- **🎨 Design** : [Figma App Desing✍](https://www.figma.com/design/msjIgYkswhnqDGOGFoteVN/Untitled?node-id=0-1&t=Azl75qVGltF1Gul1-1)
